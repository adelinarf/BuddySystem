//Buddy system
package BuddySystem
//Al finalizar cada accion se pide la siguiente
public class BuddySystem(cantidad : Int) {
    var tamano : Int = 0
    var espaciosLibres : MutableList<Int> = mutableListOf()
    var espaciosConsumidos : MutableList<Pair<String,Int>> = mutableListOf()
    init {
        this.tamano = cantidad
        this.espaciosLibres.add(cantidad)
    }
    fun recibirEntradaPorConsola(){
		println("Recibe entrada")
	}
	fun buscarEnLista(nombre : String , lista : MutableList<Pair<String,Int>>) : Int {
		var objeto : Pair<String,Int>? = lista.find { it.first == nombre }
		var salida : Int
		if (objeto != null){
			salida = lista.indexOf(objeto)
		}
		else{
			salida = -1
		}
		return salida
	}
	fun reservar(nombre : String, cantidad : Int) : Boolean { //RESERVAR <nombre> <cantidad>
		//buscar en los espacios libres y ver si se encaja con el tamano buscado si hay dos espacios libres que cumplen con lo querido
		//se pueden unir
		var salida = true
		if (buscarEnLista(nombre,this.espaciosConsumidos)!=-1){
			println("Ya existe el identificador ${nombre} en los bloques")
			salida = false
		}
		else{
			var ordenado : MutableList<Int> = this.espaciosLibres.sortedDescending().toMutableList()
			var notAssigned = true
			while (notAssigned){
				var busqueda : Int = ordenado.find { cantidad-1<it && it<=cantidad+1 } ?: -1
				if (ordenado.size ==0 || busqueda == -1 && ordenado[0] < cantidad){
					//buscar los que mejor lleguen a la cantidad
					println("No es posible reservar un bloque de tamano ${cantidad}")
					salida = false
					notAssigned = false
				}
				else if (busqueda == -1 && ordenado[0]/2 < cantidad){
					this.espaciosConsumidos.add(Pair(nombre,ordenado[0]))
					ordenado.remove(ordenado[0])
					salida = true
					notAssigned = false
				}
				else if (busqueda == -1 && ordenado[0] > cantidad){
					ordenado.set(0, ordenado[0]/2)
					ordenado.add(ordenado[0])
					salida = false
				}
				else if (busqueda != -1 && ordenado[0] >= cantidad){
					ordenado.remove(busqueda)
					this.espaciosConsumidos.add(Pair(nombre,busqueda))
					salida = true
					notAssigned = false
				}
			}
			this.espaciosLibres = ordenado
		}
		return salida
		//se reserva el espacio de nbloques asociados a un identificador
		//si ya tiene memoria reservada reporta un error e ignora o si no hay espacio lo suficientemente grande
	}
	fun liberar(nombre : String) : MutableList<Int> { //LIBERAR <nombre>
		//buscar la tupla que tiene el nombre que queremos y borrarla y anadir sy tamano a lo libre
		//libre el espacio que contiene al identificador nombre
		//Reporta un error si nombre no tiene memoria reservada
		if (buscarEnLista(nombre,this.espaciosConsumidos)==-1){
			println("El identificador ${nombre} no tiene memoria reservada")
		}
		else{
			var objeto = this.espaciosConsumidos.find { it.first == nombre } ?: Pair("",0)
			this.espaciosConsumidos.remove(objeto)
			if (this.espaciosLibres.contains(objeto.second)){
				var indice = this.espaciosLibres.indexOf(objeto.second)
				this.espaciosLibres[indice] += this.espaciosLibres[indice]
			}
			else{
				this.espaciosLibres.add(objeto.second)
			}
			if (this.espaciosLibres.size != this.espaciosLibres.distinct().count()){
				this.unir()
			}
		}
		return this.espaciosLibres
	}
	fun unir(){
		var nuevos : MutableList<Int> = mutableListOf()
		for (i in this.espaciosLibres) {
			if (nuevos.contains(i)){
				var indice = nuevos.indexOf(i)
				nuevos[indice] += nuevos[indice]
			}
			else{
				nuevos.add(i)
			}
		}
        this.espaciosLibres = nuevos
	}
	fun mostrar(){
		println("Espacios Libres")
		for (espacios in this.espaciosLibres){
			println("|".repeat(espacios) + espacios.toString())
		}		
		println("Espacios Ocupados")
		for (ocupado in this.espaciosConsumidos){
			println("/".repeat(ocupado.second) + ocupado.second.toString() +" id = "+ ocupado.first)
		}	
		//"Word".repeat(4)
		//println(this.espaciosLibres)
		//println(this.espaciosConsumidos)
		//muestra una rep grafica en texto de las listas de bloques libres
		//info de los nombres y la memoria asociada a cada uno
	}
}
