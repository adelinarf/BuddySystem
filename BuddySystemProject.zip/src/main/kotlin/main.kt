import BuddySystem.*

fun potenciaDeDos(numero : Int) : Boolean {
  if(numero==0)
    return false
  var n = numero.toDouble()
  return (Math.ceil((Math.log(n) / Math.log(2.0)))) == (Math.floor(((Math.log(n) / Math.log(2.0)))))
}

fun main() {
  println("Bienvenido al Buddy System!")
  println("Inserta la cantidad de bloques de memoria: ")
  var cantidadBloques = try { readLine()?.toInt() ?: -1 } catch (e: NumberFormatException) { -1 }
  if (cantidadBloques == -1 || !potenciaDeDos(cantidadBloques)){
    println("La cantidad de bloques debe ser un numero entero, potencia de 2")
  }
  else{
    var procesar = true
    var buddy = BuddySystem(cantidadBloques)
    while (procesar){
      var lectura = readLine() ?: "Nada"
      var listaLectura = lectura.split(" ")
      if (listaLectura[0] == "RESERVAR"){
        if (listaLectura.size == 3){
          buddy.reservar(listaLectura[1],listaLectura[2].toInt())
        }
        else{
          println("La expresion no esta definida.")
        }
      }
      else if (listaLectura[0] == "LIBERAR"){
        if (listaLectura.size == 2){
          buddy.liberar(listaLectura[1])
        }
        else{
          println("La expresion no esta definida.")
        }
      }
      else if (listaLectura[0] == "MOSTRAR"){
        if (listaLectura.size == 1){
          buddy.mostrar()
        }
        else{
          println("La expresion no esta definida.")
        }
      }
      else if (listaLectura[0] == "SALIR"){
        procesar = false
      }
      else{
        if (lectura != ""){
          println("La expresion no esta definida.")
        }        
      }
    }
  }
  println("Has salido del Buddy System")
}
